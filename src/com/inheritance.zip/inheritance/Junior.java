package com.inheritance;

public class Junior extends Person {
	Junior()
	{
		
		salary();
		super.role="Entry Level Developer ";
	}
	public void  salary()
	{
		System.out.println("salary is 25000");
		
	}

}
