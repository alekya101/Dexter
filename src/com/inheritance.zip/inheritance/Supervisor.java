package com.inheritance;

public class Supervisor extends Person{
	  Supervisor()
	  {
		super.role="Supervisor" ;
		printorganization();
		
	  }
  public void printorganization()
  {
	  System.out.println("Dexters is his organization");
  }
}
