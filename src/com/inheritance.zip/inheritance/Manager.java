package com.inheritance;

public class Manager extends Person {
	Manager()
	{
		super.name="Alekhya";
		printname();
	}
	public void  printname()
	{
	       System.out.println(" Name is Alekhya");
	}
	public void printDOB()
	{
		System.out.println("date of birth is 18/05/1993");
	}

}
