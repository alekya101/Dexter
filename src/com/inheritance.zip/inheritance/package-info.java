/**
 * 
 */
/**
 * @author aleky
 *
 */
package com.inheritance;